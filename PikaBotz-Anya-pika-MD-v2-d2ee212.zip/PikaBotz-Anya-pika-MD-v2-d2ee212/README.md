<div align="center">
  
## 𝐀𝖓𝐲𝖆 𝖇𝐲 𝕻𝖎𝖐𝖆𝖈𝖍𝖚
##   
<p align="center">
<img src="./HomeScreen/Anyapic.jpg" alt="Pika" height= "auto" width="auto"/>


</p>
<p align="center">
<a href="#"><img title="𝐐𝐔𝚵𝚵𝚴 𝚫𝚴𝐘𝚫 𝐦𝐮𝐥𝐭𝐢 𝐝𝐞𝐯𝐢𝐜𝐞." src="https://img.shields.io/badge/𝐐𝐔𝚵𝚵𝚴 𝚫𝚴𝐘𝚫 𝐦𝐮𝐥𝐭𝐢 𝐝𝐞𝐯𝐢𝐜𝐞.-red?colorA=%23ff0000&colorB=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/PikaBotz"><img title="Author" src="https://img.shields.io/badge/Author-PikaBotz-red.svg?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/PikaBotz/Anya-pika-MD-v2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/PikaBotz/Anya-pika-MD-v2?color=blue&style=flat-square"></a>
<a href="https://github.com/PikaBotz/Anya-pika-MD-v2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/PikaBotz/Anya-pika-MD-v2?color=red&style=flat-square"></a>
<a href="https://github.com/PikaBotz/Anya-pika-MD-v2/"><img title="Size" src="https://img.shields.io/github/repo-size/PikaBotz/Anya-pika-MD-v2?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FPikaBotz%2Anya-pika-MD-v2&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/PikaBotz/Anya-pika-MD-v2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</P>
</div>

##

### `DEPLOY`

<p align="center">
𝗛𝗲𝗿𝗼𝗸𝘂

<p align="center">
<a href="https://heroku.com/deploy?template=https://github.com/PikaBotz/Anya-pika-MD-v2/"><img align="center" src="https://www.herokucdn.com/deploy/button.svg" alt="Fork and deploy" /></a>
</P>

<p align="center">
𝗞𝗼𝘆𝗲𝗯

<p align="center">
<a href="https://app.koyeb.com/deploy?type=git&repository=https://github.com/PikaBotz/Anya-pika-MD-v2&branch=main&name=queen-anya"><img align="center" src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Fork and deploy" /></a>
</P>
  
  
### SCAN QR CODE

<p align="center">
<a href="http://Testing.jetus-hack.repl.co"><img src="./HomeScreen/AnyaQRscan.png" align="center" width="90" />
</div>
<p align="center">
</p>


# Install Manually 👇
## `Requirements`
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)

## `Clone Repo & Installation dependencies`
```bash
git clone https://github.com/PikaBotz/Anya-pika-MD-v2
cd Anya-pika-MD-v2

npm start
```
## `For Termux/Ssh/Ubuntu`
```bash
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/PikaBotz/Anya-pika-MD-v2
cd Anya-pika-MD-v2
npm start
```
## `For VPS`
```bash
apt install nodejs 
apt install git 
apt apt install ffmpeg 
apt apt install libwebp 
apt apt install imagrmagick
apt install bash
git clone https://github.com/PikaBotz/Anya-pika-MD-v2
cd Anya-pika-MD-v2
npm start
```
## `For 24/7 Activation (Termux)`
```bash
npm i -g pm2 && pm2 start nexus.js && pm2 save && pm2 logs
```
##
## ℂℝ𝔼𝔻𝕀𝕋𝕊
* [Nexus](https://github.com/Nexusat12)
* [Xeon](https://github.com/DGxeon)
* [Jetus](https://github.com/jetus-hack)

##
## 𝑻𝒉𝒆 𝒎𝒂𝒊𝒏 𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒓 𝑷𝒊𝑲𝒂𝑪𝒉𝒖🥵🔥
<p align="center">

<img src="./HomeScreen/Developerpic.jpg">   
<br>
<div>
<br>
