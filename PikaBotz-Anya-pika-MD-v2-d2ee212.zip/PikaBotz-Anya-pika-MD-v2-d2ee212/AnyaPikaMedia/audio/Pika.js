/* 
A modular WhatsApp Bot made by java script...
And developed by @Pika-pro

- GPL-3.0 lisence -
*/
